#!/usr/bin/env bash

python setup.py build_ext --inplace
rm -rf build
